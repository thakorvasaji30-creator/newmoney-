DRAGON VS TIGER — GITHUB PAGES SETUP (Hindi)

FILES
- index.html: website layout
- style.css: design
- script.js: game + demo login/register

GITHUB PAGES PAR PUBLISH KAREIN
1. github.com par login karein.
2. New repository par click karein.
3. Repository name: dragon-vs-tiger-game
4. Public select karein aur Create repository dabayein.
5. Add file > Upload files par click karein.
6. Is ZIP ke andar ki teen files (index.html, style.css, script.js) upload karein. ZIP file ko khud repository mein upload karne ke bajay ZIP extract karke teen files upload karein.
7. Commit changes dabayein.
8. Repository mein Settings > Pages kholein.
9. Build and deployment mein "Deploy from a branch" select karein.
10. Branch: main aur folder: /(root) select karke Save karein.
11. 1-5 minute baad Pages section mein diya gaya website URL kholein. Aam taur par URL https://YOUR-USERNAME.github.io/dragon-vs-tiger-game/ jaisa hoga.

LOGIN/REGISTER KE BAARE MEIN ZAROORI BAAT
Yeh starter version ka Login/Register browser ke localStorage mein demo account rakhta hai. Iska matlab:
- Account sirf usi browser/device mein kaam karega.
- Browser data clear karne par account/score mit sakta hai.
- Yeh secure authentication nahi hai; password browser storage mein plain text mein hota hai.
- Public website ke liye real password, payment, personal data ya sensitive information use na karein.
- Secure production login chahiye to Firebase Authentication / Supabase Auth jaise auth service ya apna secure backend set up karna hoga. Frontend HTML se akela secure account system nahi ban sakta.

GAME
- Virtual coins only; no real-money deposit, wager, or withdrawal.
- New Game score ko 1000 virtual coins par reset karta hai.
- Recent results browser mein save hote hain only when logged into the demo account.
